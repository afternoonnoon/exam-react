import type { CartItem } from "~/types/CartItem";
import type { Product } from "~/types/Product";
import { create } from 'zustand';

interface CartStore {
    items: CartItem[];
    addToCart(product: Product): void;
    removeFromCart(productId: string): void;
    updateQuantity(productId: string, quantity: number): void;
    clearCart(): void;
    getTotalItems(): number;
    getTotalPrice(): number;
}

export const useCartStore = create<CartStore>()((set) => ({
    items: [],
    addToCart: (product) => set((state) => ({
        items: [...state.items, { productId: product.id, product, quantity: 1 }]
    })),

    removeFromCart: (productId) => set((state) => ({
        items: state.items.filter(item => item.productId !== productId)
    })),

    updateQuantity: (productId, quantity) => set((state) => ({
        items: state.items.map(item =>
            item.productId === productId ? { ...item, quantity } : item
        )
    })),

    clearCart: () => set({ items: [] }),

    getTotalItems: () => {
        const state: CartStore = useCartStore.getState();
        return state.items.reduce((total, item) => total + item.quantity, 0);
    },
    getTotalPrice: () => {
        const state: CartStore = useCartStore.getState();
        return state.items.reduce((total, item) => total + item.product.price * item.quantity, 0);
    }
}));
