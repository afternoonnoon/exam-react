import type { Product } from '~/types/Product';
import { create } from 'zustand';

interface ProductStore {
    products: Product[];
    loadProducts: () => Promise<void>;
    getProductsByCategory: (category: string) => Product[];
}

export const useProductStore = create<ProductStore>()((set) => ({
    products: [],
    loadProducts: async () => {
        // Simulate loading products from a file mockData.ts
        const response = await import('~/mockData');
        set({ products: response.mockProducts });
    },
    getProductsByCategory: (category: string) => {
        const state: ProductStore = useProductStore.getState();
        if (category === 'all') {
            return state.products;
        }
        return state.products.filter(product => product.category === category);
    }
}));
